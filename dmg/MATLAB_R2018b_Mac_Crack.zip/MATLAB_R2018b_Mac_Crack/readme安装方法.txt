I offer two modes of installation:

1) standalone:
- Install choosing the option "Use a File Installation Key" and supply the following FIK
	09806-07443-53955-64350-21751-41297
- To install Matlab Production Server,using this
	40236-45817-26714-51426-39281
- Use license_standalone.lic to activate,
  or copy license_standalone.lic to %installdir%\licenses\ ,and run matlab without activation
- after the installation finishes copy the folders to %installdir% to overwriting the originally installed files

2) floating license (network license server):
- Install choosing the option "Use a File Installation Key" and supply the following FIK
	31095-30030-55416-47440-21946-54205
- To install Matlab Production Server,using this
	57726-51709-20682-42954-31195
- Use license_server.lic when asked
- after the installation finishes copy the folders to %installdir% to overwriting the originally installed files

注意：
====================================================================
1、推荐standalone方法，一定要注意在Mac下的替换路径：那个libmwlmgrimpl.dylib要复制替换路径bin\maci64\matlab_startup_plugins\lmgrimpl下面。其次是不要选择production server 工具箱，否则不会创建快捷方式。
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
2、目前发现帮助文档，单独打开的话，MATLAB R2018b会崩溃，不知道是软件bug还是破解问题（找不到其他地方需要patch了），测试很大可能是MATLAB的bug。有意思的是新版的MATLAB帮助文档，设置中文的话，真有部分中文，但是有个bug，就是设置中文后，帮助文档不能搜索索引了。
3、toolbox下的几个APP的图标双击的话，倒是没有反应，命令行模式没有问题。
*******************************************************************
4、本破解文件由dnawujun制作。
！！！！！！希望有正版的用户，也测试下，是不是也有上面的问题，另外有新版本hotfix补丁的话，及时能升级修复bug